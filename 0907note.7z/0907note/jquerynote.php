js的套件可由下列網址下載
http://jquery.com/download/
1.可下載js然後存取到伺服器
  用絕對路徑/
  jquery-3.2.1.min.js
2.設此網站為src
  https://code.jquery.com/jquery-3.2.1.min.js