<?php

$hosthame="127.0.0.1";
$database="test";
$username="root";
$password="cj;6u6xu/6";

//$link=mysqli_connect($hostname,$username,$password);

$mysqli = new mysqli($hostname, $username, $password, $database);

//$myquery=new myquery();

$i=0;


if ($result = $mysqli->query("SELECT * from gg")) {

    /* fetch object array */
    while ($row = $result->fetch_row()) {
        //echo  $row[0],$row[1];
        $test[$i][0]=$row[0];
        $test[$i][1]=$row[1];
        $i++;
        //echo "<br>"."i= ".$i."<br>";
        //echo "<br>";
    }
    /* free result set */
    $result->close();
}
else
    echo 'Fail';


for ($j=0;$j<$i;$j++){
    $A= $test[$j][0]." = ";
    $B= $test[$j][1];
    echo "<br>";
    echo json_encode(["id2"=>"id is $A","hi"=>"hi is $B"]);
    echo "<br>";
}




//$sql="INSERT INTO gg (id, hi) VALUES('7','abcdefg');";
/*mysqli_query("INSERT INTO gg (id, hi) 
    VALUES ('6', 'bbb')");*/
//$sql = "INSERT INTO 'gg' (id, hi) VALUES ("4","aaaa")";
/*mysqli_select_db($database);

$alldata="SELECT * FROM gg";

$printalldata = mysqli_query($alldata);

while($row=musql_fetch_array($result)){
	echo $row['查詢欄位1']."";
	echo $row['查詢欄位2']."<br>";
}*/

//echo $alldata;

//echo "success";
//mysqli_close($link);

?>
