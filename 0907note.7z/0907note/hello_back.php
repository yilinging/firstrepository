<?php
$myname = $_GET['name'];
sleep(5); //為了製造 ajax loading效果，所以延遲5秒
echo json_encode(["aa"=>"You input name is $myname <br>","aa2"=>"You input name2 is $myname "]);
?>