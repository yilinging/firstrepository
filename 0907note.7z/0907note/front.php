<HTML>
  <HEAD>

    <script type="text/javascript" src="/jquery-3.2.1.min.js"></script>
    <script type="text/javascript">
    $(document).ready(function () {
      $('#btn').click(function (){
       $.ajax({
        url: 'back.php',
        //cache: false,
        dataType: 'json',
        type:'GET',

        error: function(xhr) {
          //$("#loadingImg").hide();
          alert('Ajax request 發生錯誤');
        },
        success: function(response) {
          //$("#loadingImg").hide();
          alert('Ajax request 成功');
          $('#msg').html(response.id2+" # "+response.hi);
          $('#msg').fadeIn();
        }


      });

       /*
       <?php
$myname = $_GET['name'];
sleep(5); //為了製造 ajax loading效果，所以延遲5秒
echo json_encode(["aa"=>"You input name is $myname <br>","aa2"=>"You input name2 is $myname "]);
?>
*/

      /*$('#btn').click(function (){
       $.ajax({
        beforeSend:function(){$("#loadingImg").show();},
        url: 'hello.php',
        dataType: 'json',
        type:'GET',
        data: { name: $('#name').val()},
        error: function(xhr) {
          $("#loadingImg").hide();
          alert('Ajax request 發生錯誤');
        },
        success: function(response) {
          $("#loadingImg").hide();
          $('#msg').html(response.aa+" # "+response.aa2);
          $('#msg').fadeIn();
        }
      });*/
});




$('#clean').click(function(){
  $('#msg').html("");
    // document.getElementById('msg').innerHTML = "";
  });


/*$(document).ajaxStart(function(){
 $("#loadingImg").show();
});
$(document).ajaxStop(function(){
 $("#loadingImg").hide();
});*/


})


</script>
</HEAD>
<BODY>
  <div id="loadingImg" style="display:none"><img src="loading.gif"> loading...</div>
  <br><br><br>
  <div align="center">
    <input type="button" value="send" id="btn">
    <br><br><br>
    <div id="msg"> </div>
  </div>
</BODY>
</HTML>