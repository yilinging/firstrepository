<?php
post
?>

<?php

require "conf/myquery.php";

//$hosthame="127.0.0.1";
//$database="test";
//$username="root";
//$password="cj;6u6xu/6";

//$link=mysqli_connect($hostname,$username,$password);


//取值array
$myquery=new myquery();
$result=$myquery->action1();

foreach ($result as $row) {
	foreach ($row as $key => $value) {
		echo $key."->".$value;
	}
}


//取值index value
$result=$myquery->action1,'keyval');

foreach ($result as $row) {
	foreach ($row as $key => $value) {
		echo $key."->".$value;
	}
}


//迴圈
for ($i=0; $i < ; $i++) { 
	# code...
}

//從query取出
$result=$myquery->query("dsljhflsdhguhgdkf",'keyval');


//資料庫 連線
$mysqli = new mysqli($hostname, $username, $password, "test");

if ($result = $mysqli->query("SELECT * from gg")) {
    $row = $result->fetch_row();
    printf("Default database is %s.\n", $row[0]);
    $result->close();
}



if ($result = $mysqli->query("SELECT * FROM gg", MYSQLI_USE_RESULT)) 
{
	var_dump(expression)
}


if ($mysqli->connect_errno) {
    printf("Connect failed: %s\n", $mysqli->connect_error);
    exit();
}


/*$result=$myquery->action1();

foreach ($result as $row) {
    foreach ($row as $key => $value) {
        echo $key."->".$value;
    }
}

/*$result=$myquery->action1,'keyval');

foreach ($result as $row) {
    foreach ($row as $key => $value) {
        echo $key."->".$value;
    }
}*/

/*array印出
if ($result = $mysqli->query("SELECT * from gg"))
{
    while($row = $result->fetch_assoc())
    {
        print_r($row);  
    }    
}
else
    echo 'Fail';*/



/*取得mysql連線
if ($mysqli->connect_errno) {
    printf("Connect failed: %s\n", $mysqli->connect_error);
    exit();
}*/

//var_dump(expression)

/*現在database
if ($result = $mysqli->query("SELECT * from gg")) {
    $row = $result->fetch_row();
    printf("Default database is %s.\n\n", $row[0]);
*/
    
?>