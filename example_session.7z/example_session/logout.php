<?php
session_start();
unset($_SESSION['LoggedIn']);
header("location:login.php");
exit();
?>