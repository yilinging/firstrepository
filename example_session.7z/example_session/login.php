<?php 
session_start();
include_once "sql.php";
?>
<!DOCTYPE html>
<HEAD>

  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
  <script type="text/javascript" src="//code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
  <script type="text/javascript">

  function checkform(){
    if (document.loginform.username.value.length==0 || document.loginform.username.value=="請輸入工號"){
      alert("請輸入工號");
      document.loginform.username.focus();
      return false;
    }
    if (document.loginform.password.value.length==0 || document.loginform.password.value=="password"){
      alert("請輸入密碼");
      document.loginform.password.focus();
      return false;
    }
    return true;
  }
  </script>
  <style type="text/css" class="init">
  h3{
    text-align:center;
    margin:20px 0;
    color:#369;
  }
  p{margin:10px 0;}
  input{padding:5px;
    width:235px;}
    .loginBox{
      width:250px;
      padding:20px 20px;
      border:1px #333 solid;
      background:#FFF;
      margin:180px auto;
      opacity:0.9;
      filter:alpha(opacity=90);
    }
    .inputWidth{
      width:235px;
    }
    .loginBtn{
      padding:3px 0;
      background-color:#D8F0F3;
      border:1px #69C solid;
      width:250px;
      cursor:pointer;
      font-weight:bold;
      padding:5px;
    }
    </style>

  </HEAD>

  <BODY>
   <?php
   if(!empty($_SESSION['LoggedIn']))
    echo "<script>location.href = \"testcode_front.php\"</script>";
   else if(!empty($_POST['username']) && !empty($_POST['password']))
   {

    $username = $_POST['username'];
    $password = $_POST['password'];   

    if(ssh2_auth_password($connection, $username, $password)==true)
    {
      
      //echo "success"; 帳號密碼輸入正確
      $stmt = $informix->prepare("SQL語法");
      $stmt->execute();
      if(count($stmt->fetchAll(PDO::FETCH_ASSOC))>0)
      {
        $_SESSION['LoggedIn']=$username; 
        //echo "success2"; //有amsr140資料庫權限
        echo "<script>location.href = \"testcode_front.php\"</script>";
      }
      else
      {
        //echo "false2"; //帳號密碼輸入正確，但無權限
        echo "您無權使用，請洽管理員！";
        echo "<p class='center'><a href='login.php'>重新登入</a></p>";
      }
    }    
    else
    {
      //echo "false"; //帳號密碼輸入錯誤 
      echo "<div class='loginBox'>";
      echo "<p class='error'>帳號密碼錯誤 或 驗證碼錯誤</p>";
      echo "<p class='center'><a href='login.php'>重新登入</a></p>";
      echo "</div>";
    }

  }
  else{
    ?>
    <div class="loginBox" align="center">
      <h3>登入</h3>
      <form method="post" action="login.php" name="loginform" onsubmit="return checkform();">
        <p>請輸入工號<input type="text" name="username" value="" autofocus /></p>
        <p>請輸入密碼<input type="password" name="password"  /></p>
        <div class="line"></div>
        <p><input name="login" type="submit" value="登入" class="loginBtn" /></p>
      </form>
    </div>
  </BODY>
<?php
}
?>
</HTML>


