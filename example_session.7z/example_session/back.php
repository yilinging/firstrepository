<?php
session_start();
$userid=$_SESSION['LoggedIn']; //獲取目前登入者id




  else //為空則利用session獲取目前登入者id，並帶出姓名
  {
    $get_wbb[$data_position][9] = $userid;
    $array_gen02 = db_select("SELECT gen02 FROM gen_file WHERE gen01='{$get_wbb[$data_position][9]}' ",$data_position);//從gen_file中找出需要的資料，姓名
    $get_gen02[$data_position] = $array_gen02[$data_position];
  }

  echo json_encode( $get_all);

?>