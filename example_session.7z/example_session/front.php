<?php 
session_start();
//include_once "sql.php";
?>
<!DOCTYPE html>
  <HEAD>

    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script type="text/javascript" src="//code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
   
    <script type="text/javascript">

    $(document).ready(function() {
      //先登入admin，如果有得到session，則可以進入本頁面
          document.getElementById("wbb01").focus(); //讓id欄位get focus

          var counter = 1;
          var myalldata = new Array();

          var table = $('#example').DataTable( {
              "bPaginate":false, 
              "bInfo":false, 
              "bFilter":false, 
              "bSort":false,
              keys: true,
              //autoFill: true, 

              "columns": [
              {
                "className": 'details-control',
                "orderable": false,
                "data": null,
                "defaultContent": ''
              },{  },{  },{  },{  },{  },{  },{  },{  },{  },{  },{  },{  },{  },{  },{  }
              ]

          } );

          function clearall(){
            $('#showmessage').text("");
            $('#showmessage2').text("");
            $('#showmessage3').text("");
          }


          function addvalue()
          {
            $.ajax({
              url: 'back.php',
              type:'GET',
              dataType: 'json',

              data: { wbb01: $('#wbb01').val() },
              error: function(xhr){
                console.log(xhr);
                alert('Ajax request 發生錯誤1');
              },
              success: function(response) {

                clearall();
                if(response[31]=='5')
                {
                  console.log(response);

                  if( (table.data().length) > 0 )
                  {
                    for( var i = 1 ; i< counter ; i++ )
                    {
                      if( response[1] == myalldata[i][1] )
                      {
                        response[31]='3';
                        $('#wbb01').val("");
                        $('#showmessage').text(response[1]+" 索引資料已重複！").css( 'color', 'red' );
                      }
                    }  
                  }
                  if( response[31]=='5' )
                  {
                    if(response[5]=='0.00000' || response[5]=='')
                    {
                      $('#showmessage').text(response[1]+" 無秤重資訊，請重新確認！").css( 'color', 'red' );
                      response[5]='';
                      //alert( table.cell(this,5).data() );
                       var rowNode = table.row.add( [ '', response[1], response[2], response[3], response[4], response[5], response[6], response[7], response[8], response[9], response[10], response[11], response[12], response[13], response[14], response[15],] ).draw().node();
                       //table.column(4).select.addClass('highlight');
                       //$('td').eq(5).addClass('highlight');//success change to blue

                       $('<input id=inputbox size=9 maxlength=9 />').appendTo( $('tr:eq('+counter+') td:eq(5)').addClass('highlight') );  //將欄位改成inputbox並focus
                          document.getElementById("inputbox").focus(); //讓inputbox 欄位get focus
                          $('tr:eq('+counter+') td:eq(5)').keydown(function(event){
                          if(event.which == 13)
                          {
                            var position=counter-1;
                            
                            response[5]= $('#inputbox').val(); //getvalue
                            if(response[5]!=null && response[5]!=undefined && (response[5].trim())!='' && response[5]>0)
                            {
                              clearall();
                              //alert(response[16]); //0.000, -15.000
                              var waw03 = response[16];
                              var wbb082=$('#inputbox').val();
                              var wbb10 = Math.floor(wbb082/response[4]+parseFloat(waw03))+".000"; //502-504

                              if( wbb10>=30000 )
                              {
                                clearall();
                                $('#inputbox').val(""); 
                                $('#showmessage').text("數量為 "+wbb10+"，生產數量大於30000，請重新確認").css( 'color', 'red' );
                              }

                              else
                              {
                                if(wbb10>=4000)
                                  $('#showmessage2').text("該筆資料數量超過4000，請特別注意").css( 'color', 'red' );
                                $('tr:eq('+position+') td:eq(6)').text(wbb10);
                                $('#showmessage').text(response[1]+"生產數量為 "+wbb10).css( 'color', 'black' );
                                $('#inputbox').replaceWith("<label>"+$('#inputbox').val()+"</label>"); //change textbox int lable
                                response[6] = wbb10;  
                                myalldata[counter-1][5]=(Math.round(response[5]*10))/10;
                                //myalldata[counter-1][6] = response[6];
                                myalldata[counter-1][6]=(Math.round(response[6]));
                                document.getElementById("wbb01").focus(); ///讓id 欄位get focus
                              }
                            }
                            else
                            {
                              clearall();
                              $('#inputbox').val(""); 
                              $('#showmessage').text(response[1]+" 無秤重資訊，請重新確認！").css( 'color', 'red' );
                            }
                            console.log(response);
                          }
                        });

                    }
                    else
                      var rowNode = table.row.add( [ '', response[1], response[2], response[3], response[4], response[5], response[6], response[7], response[8], response[9], response[10], response[11], response[12], response[13], response[14], response[15],] ).draw().node();

                    myalldata[counter]=new Array();
                    for (var i=1; i<=22; i++)
                      myalldata[counter][i] = response[i];
                    myalldata[counter][5]=(Math.round(response[5]*10))/10;
                    myalldata[counter][6]=(Math.round(response[6]));

                    counter=counter+1;

                    if( ((table.data().length)%2) == 0 )
                      $(rowNode).css({'text-align':'center','background-color':'LightGoldenRodYellow'});
                    else
                      $(rowNode).css({'text-align':'center','background-color':'Lavender'});

                    if(response[32]=='1')
                      $('#showmessage').text(response[1]+" 部品已入庫or移轉記錄！").css( 'color', 'red' );

                    if(response[32]=='2')
                      $('#showmessage').text(response[1]+" 品檢NG品，允放行調整數量！").css( 'color', 'red' );

                    if(response[33]=='1')
                      $('#showmessage2').text(response[1]+" 無層別資料！").css( 'color', 'red' );  

                    if(response[34]=='1')
                      $('#showmessage3').text(response[1]+" 已有品管檢驗放行！").css( 'color', 'red' );

                    $('#wbb01').val("");
                  }
                }
                else if(response[31]=='1')
                {
                  $('#wbb01').val("");
                  $('#showmessage').text("空白資料！").css( 'color', 'red' );
                }
                else if(response[31]=='2')
                {
                  $('#wbb01').val("");
                  $('#showmessage').text("查無索引資料！").css( 'color', 'red' );
                }
                else
                {
                  $('#wbb01').val("");
                  $('#showmessage').text("索引編號尚未烘烤！").css( 'color', 'red' );
                }      
              }
            });

          }

          $('#addValue').click(function (){
            var engValue = $('#wbb01').val();
            re = /[a-zA-Z0-9]/;
            if(!re.test(engValue)) 
            {
              $('#wbb01').val("");
              $('#showmessage').text("請輸入正確索引資料！").css( 'color', 'red' );
            }  
            else
              addvalue();
          });

          $('#wbb01').keydown(function(event){
            if(event.which == 13)
              {
                var engValue = $('#wbb01').val();
                re = /[a-zA-Z0-9]/;
                if(!re.test(engValue)) 
                {
                  $('#wbb01').val("");
                  $('#showmessage').text("請輸入正確索引資料！").css( 'color', 'red' );
                }  
                else
                  addvalue();
              }
          });

          $('#deleteTable').on('click',function(){
            if(counter>0)
            {
              for( var i = 1 ; i< counter ; i++ )
                for ( var j = 1 ; j <= 15 ; j++ )
                  myalldata[i][j]='';
              }
              table.clear().draw();
              clearall();
            });

          $('#example tbody').on('click', 'td.details-control', function () { 
                    var deleterow = (table.row(this).index()); //row列從0開始
                    myalldata.splice( deleterow+1 ,1 );
                    counter=counter-1;
                    table.row( $(this).parents('tr') ).remove().draw();
                    clearall();
                  } );

          $('#exit').on('click', function(){
            alert('清除資料');
            alert('Nothing happened');
            table.clear().draw();
            clearall();
          });

          $('#Print').click(function (){
            clearall();
            
            if(counter>0)
            {


              for( var i = 1 ; i< counter ; i++ )
              {
                console.log(myalldata[i][1]+" "+myalldata[i][12]+" "+myalldata[i][17]+" / "+myalldata[i][15]+" #"+myalldata[i][18]+" "+myalldata[i][19]+"/"+myalldata[i][20]+" "+myalldata[i][21]+" "+myalldata[i][22]+" 數量： "+myalldata[i][6]+" ("+myalldata[i][5]+"g) ("+myalldata[i][9]+"層) "+myalldata[i][7]+"番  作業員："+myalldata[i][3]+" 備註："+myalldata[i][13]+" "+myalldata[i][10]);
              }
            }
          });
        

    });

</script>

<style type="text/css" class="init">
td.details-control {
  background: url('details_close.png') no-repeat center center;
  cursor: pointer;
}
td.highlight{
  front-weight:bold;
  color:blue;
}
</style>

</HEAD>
<BODY >
 <?php
   if(!empty($_SESSION['LoggedIn']))
   {
    ?>
  <div align="center">
   <br><h3>條碼列印</h3><br>
   目前掃描索引編號  <input id="wbb01" size=12  maxlength=12 > <button id="addValue">新增索引編號</button> <br><br>
   <button id='deleteTable'>清除表格</button>
   <button id='Print'>列印</button>
   <button id ='exit'>結束</button>
   <button id ='logout' onclick="location.href='logout.php'">登出</button>
   <br><br>
   <table id="example" class="display" cellspacing="0" width="100%" >
    <thead>
      <tr>
        <th></th>
        <th>索引編號/包裝</th>
        <th>作業員</th>
        <th>姓名</th>
        <th>單重(g)</th>
        <th>秤重(g)</th>
        <th>生產數量</th>
        <th>番/機台</th>
        <th></th>
        <th>層級</th>
        <th></th>
        <th>日期</th>
        <th>料件編號</th>
        <th>備註</th>
        <th></th>
        <th></th>
      </tr>
    </thead>
  </table>
  <br> <div id="showmessage"></div> <div id="showmessage2"></div><div id="showmessage3"></div><br>
</div> 
</BODY>
<?php
 }
 else   
  echo "<script>location.href = \"login.php\"</script>"; 
?>
</HTML>