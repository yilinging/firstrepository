<?php
session_start();
error_reporting(0);

$server='server網域';
$connection = ssh2_connect($server, 22);

$informix = new PDO("", "帳號", "密碼");


?>


