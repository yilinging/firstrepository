INFORMIX 4GL

BDL/4GL 程式標準架構
---以下為基本順序,沒有用到的話就省略吧(大寫為語法,小寫為變數或自訂資料)

IMPORT os		#需要在4gl啟始處(DATABASE指令之前)
DATABASE dbname		#必需放在第一行
GLOBALS			#宣告全域變數
  DEFINE ...		#可有多行
  END GLOBALS		
DEFINE ...		#宣告整支程式共用的變數
MAIN …  END MAIN	#程式進入時開始點,只能有一個,如沒有就僅能被含入
FUNCTION …END FUNCTION #自訂 FUNCTION或程序,使用CALL 呼叫

---預設全域變數或內設FUNCTION
INT_FLAG	使用者按下中斷鍵時將此變數設為 True(配合DEFER INTERRUPT)
STATUS		最近一次執行 SQL 指令的結果錯誤碼，成功=0
NOTFOUND	ERR:-6005, A column cannot be found. 
SQLCA		最近一次執行 SQL 指令的結果，為RECORD

---MAIN 內------
DEFER INTERRUPT 	程式不可中斷,通常配合INT_FLAG自訂中斷程序
SET ... TO ...		設定參數如 set isolation to dirty read

---MAIN/FUNCTION內------
OPTION ACCEPT KEY control-z     KEY設定
OPEN FORM s_a FROM "p010a"	開啟FORM
OPEN WINDOW s_a AT 3,15 WITH FORM 'p010p' ATTRIBUTE(border)  
DISPLAY	變數			將變數/字串顯示到畫面
DISPLAY BY NAME 名稱 	 	將變數/字串顯示到對應的欄位
DISPLAY 變數 TO 欄位名稱 	將變數/字串顯示到欄位(ARRAY)
INPUT				將指定欄位的值儲存到變數中
INPUT 變數 FROM 欄位名稱 	輸入用法
INPUT ARRAY 變數 FROM 欄位名稱 	輸入陣列用法
INPUT BY NAME 名稱 		變數名稱與欄位名稱相同
INPUT ....　WITHOUT DEFAULTS	不使用欄位預設值
CONSTRUCT BY NAME w_where ON pno, pname... 	自動串接SQL查詢語法中的WHERE字串
PREPARE stmtq FROM w_sql			先LET w_sql='select ...',檢查 SQL
EXECUTE stmtq USING m.*				A-異動資料進行
DECLARE pcurq SCROLL CURSOR FOR stmtq		B-宣告資料傳輸指標(scroll可省略)
FOREACH pcurq INTO m.* ... EDN FOREACH		B1.迴圈用法,自動開關
OPEN  pcurq ;					B2.打開游標
fetch [first/last/prior/next] pcurq into m.* 	B2.首末上下,省略=目前
CLOSE pcurq ;					B2.關閉游標