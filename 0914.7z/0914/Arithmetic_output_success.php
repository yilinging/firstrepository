<?php
error_reporting(-1);
ini_set("display_errors", 1);
header("Content-Type:text/html; charset=utf-8");
require_once "vendor/autoload.php";
$file = 'Arithmetic.xlsx';


$objPHPExcel = new PHPExcel();

try {
 $objPHPExcel = PHPExcel_IOFactory::load($file);
} catch(Exception $e) {
 die('Error loading file "'.pathinfo($file,PATHINFO_BASENAME).'": '.$e->getMessage());
}

// echo $objPHPExcel->getActiveSheet()->getCell('A3')->getValue().'<br />';
$A1 = $objPHPExcel->getActiveSheet()->getCell('A1')->getValue();
$A2 = $objPHPExcel->getActiveSheet()->getCell('A2')->getValue();
$A3 = $objPHPExcel->getActiveSheet()->getCell('A3')->getValue();
$B1 = $objPHPExcel->getActiveSheet()->getCell('B1')->getValue();
$B2 = $objPHPExcel->getActiveSheet()->getCell('B2')->getValue();
$B3 = $objPHPExcel->getActiveSheet()->getCell('B3')->getValue();
$C1 = $objPHPExcel->getActiveSheet()->getCell('C1')->getValue();
$C2 = $objPHPExcel->getActiveSheet()->getCell('C2')->getValue();
$C3 = $objPHPExcel->getActiveSheet()->getCell('C3')->getValue();

echo $A1." ".$A2." ".$A3." = ".($A1+$A3).'<br />';
echo $B1." ".$B2." ".$B3." = ".($B1-$B3).'<br />';
echo $C1." ".$C2." ".$C3." = ".($C1*$C3).'<br />';


?>
