<?php
error_reporting(-1);
ini_set("display_errors", 1);
require_once "vendor/autoload.php";



$objPHPExcel = new PHPExcel();

$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A1', '8')
            ->setCellValue('A2', '+')
            ->setCellValue('A3', '7')
            ->setCellValue('B1', '6')
            ->setCellValue('B2', '-')
            ->setCellValue('B3', '5')
            ->setCellValue('C1', '4')
            ->setCellValue('C2', '*')
            ->setCellValue('C3', '3')
            ->setCellValue('D1', '2')
            ->setCellValue('D2', '/')
            ->setCellValue('D3', '1');

//$PHPExcel_IOFactory=new PHPExcel_IOFactory();




header('Content-Type: application/application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="Arithmetic.xlsx"');
header('Cache-Control: max-age=0');
// If you're serving to IE 9, then the following may be needed
header('Cache-Control: max-age=1');
// If you're serving to IE over SSL, then the following may be needed
header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
header ('Pragma: public'); // HTTP/1.0
$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
$objWriter->save('php://output');
//$objPHPExcel->getActiveSheet()->setCellValue('C1', $_POST['C']);
echo $objPHPExcel->getActiveSheet()->getCell('B1')->getValue().'<br />';
exit;

?>
