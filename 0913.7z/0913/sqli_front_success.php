<HTML>
  <HEAD>
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script type="text/javascript">

    $(document).ready(function () {
      $.ajax({
        url: '0912_back.php',
        type:'GET',
        dataType: 'json',
        //cache: false,
                //data: { sqlselect: $('#sqlselect').val()},
                data: { sqlselect: $('#sqlselect').val(),sqlinsertid: $('#sqlinsertid').val(),sqlinserthi: $('#sqlinserthi').val()},
                error: function(xhr) {
                  console.log(xhr);
                  alert('Ajax request 發生錯誤1');

                },
                success: function(response) {
                 $('#msg1').html(response.sqlid[0][0]);
                 $('#msg2').html(response.sqlid[0][1]);
                 $('#msg3').html(response.sqlid[1][0]);
                 $('#msg4').html(response.sqlid[1][1]);
                 $('#msg5').html(response.sqlid[2][0]);
                 $('#msg6').html(response.sqlid[2][1]);
                 $('#msg7').html(response.sqlid[3][0]);
                 $('#msg8').html(response.sqlid[3][1]);
                 $('#msg9').html(response.sqlid[4][0]);
                 $('#msg10').html(response.sqlid[4][1]);          
                 $('#msg11').html(response.sqlid[5][0]);  
                 $('#msg12').html(response.sqlid[5][1]);
                 $('#msg13').html(response.sqlid[6][0]);  
                 $('#msg14').html(response.sqlid[6][1]);
         /* $('#msg1').fadeIn();
          $('#msg2').fadeIn();
          $('#msg3').fadeIn();
          $('#msg4').fadeIn();
          $('#msg5').fadeIn();
          $('#msg6').fadeIn();
          $('#msg7').fadeIn();
          $('#msg8').fadeIn();
          $('#msg9').fadeIn();
          $('#msg10').fadeIn();
          $('#msg11').fadeIn();
          $('#msg12').fadeIn();
          $('#msg13').fadeIn();
          $('#msg14').fadeIn();*/
        }
      });


$('#btn').click(function (){
 $.ajax({
   url: '0912_back.php',
   dataType: 'json',
   type:'GET',
   data: { sqlselect: $('#sqlselect').val(),sqlinsertid: $('#sqlinsertid').val(),sqlinserthi: $('#sqlinserthi').val()},
        //data: { sqlselect: $('#sqlselect').val()},
        error: function(xhr) {
          console.log(xhr);
          alert('Ajax request 發生錯誤2');
        },
        success: function(response) {
          $('#msg15').html(response.sqlresult[0]);
          $('#msg16').html(response.sqlresult[1]);
        }
      });
});


//可insert值，似乎是dataType:json出錯 parsererror
$('#btn2').click(function (){
 $.ajax({
   url: '0912_back.php',
   dataType: 'json',
   type:'GET',
   data: { sqlinsertid: $('#sqlinsertid').val(),sqlinserthi: $('#sqlinserthi').val()},
        //data: { sqlselect: $('#sqlselect').val()},
        error: function(xhr) {
          console.log(xhr);
          alert('Ajax request 發生錯誤3');
        },
        success: function(response) {
        }
      });
});
/*$('#clean').click(function(){
  $('#msg').html("");
});*/

})

</script>
</HEAD>
<BODY>

  <br><br><br>
  <div align="center">
    <table border="1" >
      　<tr>
        　<td width=100 height=30 align=center>id</td>
        <td width=100 height=30 align=center>hi</td>
      　</tr>
      <tr>
        　<td id="msg1" width=100 height=30 align=center></td>
        <td id="msg2" width=100 height=30 align=center></td>
      　</tr>
      <tr>
        　<td id="msg3" width=100 height=30 align=center></td>
        <td id="msg4" width=100 height=30 align=center></td>
      　</tr>
      <tr>
        　<td id="msg5" width=100 height=30 align=center></td>
        <td id="msg6" width=100 height=30 align=center></td>
      　</tr>
      <tr>
        　<td id="msg7" width=100 height=30 align=center></td>
        <td id="msg8" width=100 height=30 align=center></td>
      　</tr>
      <tr>
        　<td id="msg9" width=100 height=30 align=center></td>
        <td id="msg10" width=100 height=30 align=center></td>
      　</tr>
      <tr>
        　<td id="msg11" width=100 height=30 align=center></td>
        <td id="msg12" width=100 height=30 align=center></td>
      　</tr>
      <tr>
        　<td id="msg13" width=100 height=30 align=center></td>
        <td id="msg14" width=100 height=30 align=center></td>
      　</tr>
    </table><br>
    Enter your SQL select id <br>
    <input type="text" id="sqlselect"> <br><br>
    <input type="button" value="send" id="btn">
    <br><br><br>

    SQL select result <br>
    <table border="1" >
      　<tr>
        　<td id="msg15" width=100 height=30 align=center></td>
        <td id="msg16" width=100 height=30 align=center></td>
      　</tr>

    </table><br>

    SQL insert <br>
    <input type="text" id="sqlinsertid"> <br><br>
    <input type="text" id="sqlinserthi"> <br><br>
    <br>
    <input type="button" value="send" id="btn2">


  </div>
</BODY>
</HTML>