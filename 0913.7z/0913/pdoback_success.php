<?php
//首先，先來定義資料庫相關存取資料
$db_host="127.0.0.1";
$db_user="root";
$db_pass="cj;6u6xu/6";
$db_select="test";

//使用PDO存取資料庫時，需要將資料庫依下列格式撰寫，讓程式讀取資料庫
$dbconnect = "mysql:host=".$db_host.";dbname=".$db_select;

$mysqlselect = $_GET['sqlselect'];
$mysqlinsertid = $_GET['sqlinsertid'];
$mysqlinserthi = $_GET['sqlinserthi'];
$mysqldeleteid = $_GET['sqldeleteid'];
$mysqlupdateid = $_GET['sqlupdateid'];
$mysqlupdatehi = $_GET['sqlupdatehi'];

//try
//{
//建立使用PDO方式連線的物件，並放入指定的相關資料
$dbgo = new PDO($dbconnect, $db_user, $db_pass);

$j=0;
//建立查詢資料表的SQL語法
$sql = "SELECT * FROM gg";

if($result = $dbgo->prepare($sql)){
  $result->execute();
  while($row=$result->fetchAll(PDO::FETCH_ASSOC)){
    //print_r($row);
    foreach ($row as $arrValues){
      $i=0;
      foreach ($arrValues as $key => $val){
        //echo $val;
        //echo "<br>";
        if($i==0)
          $AB[$j][0]= $val;
        else
         $AB[$j][1]= $val;
       $i++;
     }
     $j++;
   }
 }
}
//}catch(PDOException $e){
  //echo $e->getMessage();
//  exit;

//}
for ($x=0;$x<$j;$x++){
    //一維陣列
  for ($y=0;$y<2;$y++){
    //echo $AB[$x][$y]."  ";
    if ($mysqlselect==$AB[$x][0])
    {
      $selectresultid=$AB[$x];
    }
    
  }
}

echo json_encode(["sqlid"=>$AB,"sqlresult"=>$selectresultid]);
$result1 = $dbgo->query("INSERT INTO gg VALUES ($mysqlinsertid,'$mysqlinserthi')");
$result2 = $dbgo->query("delete from gg where id='$mysqldeleteid'");
$result3 = $dbgo->query("UPDATE gg SET hi='$mysqlupdatehi' WHERE id=$mysqlupdateid");
//insert into 語法ok

/*if ($result2 = $dbgo->query("INSERT INTO gg VALUES ($mysqlinsertid,'$mysqlinserthi')")) {

  $result2->close();
}
//else
echo 'Fail';*/


//delete語法ok
/*if ($result3 = $dbgo->query("delete from gg where id='$mysqldelete'")) {

  $result3->close();
}
else
echo 'Fail';  */


//update語法ok
/*
if ($result4 = $dbgo->query("UPDATE gg SET hi='$mysqlupdaethi' WHERE id=$mysqlupdateid")) {

    $result4->close();
}
else
echo 'Fail2';*/

$dbgo = NULL;

?>