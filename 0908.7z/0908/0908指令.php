 1  cd /etc/yum.repos.d/
    2  ls -ls
    3  yum
    4  export http_proxy=http://144.144.2.57:3128
    5  export https_proxy=http://144.144.2.57:3128
    6  cd
    7  rmp -qa |grep yum
    8  rpm -qa |grep yum
    9  export http_proxy=http://144.144.2.57:3128
   10  export https_proxy=http://144.144.2.57:3128
   11  rpm -qa |grep yum
   12  ls
   13  cd var
   14  cd home
   15  cd ..
   16  ls
   17  cd var
   18  ls
   19  cd cache
   20  ls
   21  cd
   22  yum check-update
   23  yum list
   24  yum list php
   25  yum info php
   26  uname -or
   27  cat /etc/lsb-release
   28  yum list php
   29  cd ..
   30  ls
   31  cd cat
   32  cd etc
   33  ls
   34  cd centos-release
   35  usname -a
   36  cd ..
   37  usname -a
   38  cat/etc/centos-release
   39  uname -a
   40  yum - install phw70w
   41  yum -y install php70w
   42  yum search epel-release
   43  yum instal epel-release
   44  lsb_release -a
   45  uname -a
   46  ls
   47  cd dev
   48  ls
   49  cd cdrom
   50  ls -l /dev/cdrom
   51  cd ..
   52  ls
   53  cd mnt
   54  ls
   55  sudo mount -t iso9660 -o ro /dev/cdrom /mnt cdrom
   56  ls
   57  cd..
   58  cd
   59  ls
   60  cd ..
   61  ls
   62  cd mnt
   63  ls
   64  cd ..
   65  cd
   66  ls
   67  cd ..
   68  ls
   69  sudo mount -t iso9660 -o ro /dev/cdrom /mnt cdrom
   70  ls
   71  cd mnt
   72  ls
   73  mount /dev/sr0 /mnt/cdrom
   74  mkdir /mnt/cdrom
   75  cd mnt
   76  cd mnk
   77  ls
   78  mount /dev/sr0 /mnt/cdrom
   79  cd dev
   80  cd..
   81  cd ..
   82  cd dev
   83  ls
   84  mount /dev/cdrom  /mnt/cdrom
   85  df cdrom
   86  ls
   87  cd ..
   88  ls
   89  mount /dev/cdrom /mnt
   90   cd/mnt
   91  cd /mnt
   92  ls
   93  rmdir cdrom
   94  ls
   95  yum list
   96  cd ..
   97  cat /etc/os-release
   98  rpm -Uvh https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm
   99  rpm -Uvh https://mirror.webtatic.com/yum/el7/webtatic-release.rmp
  100  rpm -Uvh https://mirror.webtatic.com/yum/el7/webtatic-release.rpm
  101  yum install php70w
  102  yum info php
  103  yum list php
  104  ls
  105  cd var/www
  106  ls
  107  cd html
  108  ls
  109  cd..
  110  cd ..
  111  yum -y install php70w
  112  systemct1 restart httpd.service
  113  systemctl restart httpd.service
  114  ls
  115  cd html
  116  ls
  117  cd ..
  118  cd
  119  ls
  120  yum install httpd
  121  yum install httpd mysql mysql-server php php-mysql
  122  cd..
  123  ls
  124  cd
  125  cd ..
  126  cd etc/httpd/conf
  127  ls
  128  cd ..
  129  ls
  130  cd conf.d
  131  ls
  132  cd ..
  133  cd /var/www
  134  ls
  135  cd html
  136  ls
  137  cd /var /www/error
  138  ls
  139  vim /etc/hosts
  140  yum install vim
  141  vim /etc/hosts
  142  vim /etc/httpd/conf/httpd.conf
  143  cd /etc/httpd/conf.d
  144  ls
  145  ll *.conf
  146  /etc/init.d/httpd start
  147  yum install httpd
  148  yum install mysql
  149  cd ..
  150  cd
  151  yum install mysql mysql-server
  152  service mysqld start
  153  systemct1 start mysql
  154  yum install mysql-community-server
  155  rpm -Uvh http://dev.mysql.com/get/mysql-community-release-el7-5.noarch.rpm
  156  yum install mysql-community-server
  157  ls /usr/bin
  158  /usr/bin/systemctl enable mysqld
  159  /usr/bin/systemctl start mysqld
  160  /usr/bin/mysql_secure_installation
  161  yum -y install httpd
  162  systemctl start httpd.service
  163  systemctl enable httpd.service
  164  firewall-cmd --permanent --zone=public --add-service=http
  165  firewall-cmd --permanent --zone=public --add-service=https
  166  firewall -cmd --reload
  167  firewall-cmd --reload
  168  vim /ect/httpd/conf/httpd.conf
  169  yum -y install php70w
  170  systemctl restart httpd.service
  171  cd /etc
  172  ls
  173  vim php.ini
  174  cd /var/www/html
  175  ls
  176  pwd
  177  vim info.php
  178  php /var/www/html/info.php
  179  cd
  180  yum search php
  181  yum -y install php70w-mysql
  182  yum -y install php70w-pdo php70w-gd php70w-ldap php70w-odbc php70w-pear.noarch php70w-xml php70w-xmlrpc php70w-mbstring php70w-snmp php70w-soap php70w-mcrypt curl curl-devel
  183  mysql_secure_installation
  184  yum install php
  185  systemctl restrat httpd.service
  186  systemctl restart httpd.service
  187  php -v
  188  sudo ip addr show
  189  php /var/www/html/info.php
  190  vim /var/www/html/info.php
  191  php /var/www/html/info.php
  192  php /var/www/html/test.php
  193  vim /var/www/html/test.php
  194  php /var/www/html/test.php
  195  ifconfig
  196  nslookup
  197  yum install nslookup
  198  nslookup [domain_name|IP]
  199  cd /var/www
  200  ls
  201  cd html
  202  ls
  203  rename test.php index.php
  204  mv test.php index.php
  205  ls
  206  cat index.php
  207  cd ..
  208  ls
  209  cd /etc/init.d
  210  ls
  211  pwd
  212  cd /etc/httpd/conf
  213  ls
  214  vim httpd.con
  215  irm httpd.com
  216  rm httpd.com
  217  rm httpd.con
  218  vim httpd.conf
  219  pwd
  220  vim httpd.conf
  221  php /var/www/html/index.php
  222  cd /var/www/html
  223  ls
  224  ifconfig
  225  ls
  226  vim index.php
  227  cd /etc
  228  ls
  229  cd yu
  230  cd yum
  231  ls
  232  cd /etc/yum.repos.d/
  233  ls
  234  cat mysql-community-source.repo
  235  cd
  236  cd ..
  237  ls
  238  cd usr
  239  cd local
  240  ls
  241  cd mysql
  242  cd bin
  243  ls
  244  cd ..
  245  cd
  246  find mysql
  247  cd /usr/bin
  248  ls
  249  cd
  250  mysql -u root
  251  mysql -u root password ling
  252  mysql -uroot ling
  253  mysql -u root ling
  254  /usr/bin/mysql_secure_installation
  255  mysql -u root -p
  256  cd /var/www/html/
  257  ls
  258  vi info.php
  259  cd /etc/php.d
  260  ls
  261  vi pdo.ini
  262  yum php70w-xml
  263  yum install php70w-xml
  264  yum install php70w-ldap
  265  ls -ls
  266  ls
  267  yum install php70w-mongodb
  268  ls -ls
  269  mysql -u root -p
  270  df -h
  271  fdisk -l
  272  cd /dev
  273  ls
  274  cd cdrom
  275  ls
  276  cd cdrom
  277  cd ..
  278  mount
  279  lsblk
  280  mkdir mycdrom
  281  ls
  282  cd var
  283  ls
  284  cd www
  285  ls
  286  cd html
  287  cd
  288  ls
  289  cd /var/www/html
  290  ls
  291  vim sql.php
  292  systemctl status httpd
  293  systemctl enable httpd
  294  systemctl disable httpd
  295  systemctl enable httpd
  296  systemctl enable mysql
  297  systemctl enable mysqld
  298  systemctl disble mysqld
  299  systemctl disable mysqld
  300  systemctl enable mysqld
  301  ps aux
  302  ps aux | more
  303  ps aux | grep yum
  304  ps aux | grep httpd
  305  ls
  306  vi gg.php
  307  php gg.php
  308  cd /var/www/html/
  309  ls
  310  php gg.php &>pp.log &
  311  ls
  312  tail -n 10 pp.log
  313  head -n 10 pp.log
  314  cd /var/www
  315  ls
  316  cd html
  317  ls
  318  nohup gg.php >/dev/null 2>&1 &
  319  nohup php gg.php >/dev/null 2>&1 &
  320  hostnamectl set-hostname WorkOrder
  321  hostnamectl
  322  systemctl status firewalld
  323  systemctl status iptables
  324  systemctl status iptable
  325  systemctl status firewalld
  326  firewalld-cmd --list-all
  327  firewalld-cmd --list
  328  firewalld --list
  329  firewalld --list-all
  330  firewall --list-all
  331  firewall-cmd --list-all
  332  cd /usr/lib/firewalld/services
  333  ls
  334  vi ldaps.xml
  335  firewall-cmd --list-all
  336  firewall-cmd --reload
  337  firewall-cmd --list-all
  338  firewall-cmd --zone=public --permanent --add-service=nfs
  339  firewall-cmd --reload
  340  firewall-cmd --list-all
  341  firewall-cmd --zone=public --permanent --remove-service=nfs
  342  firewall-cmd --reload
  343  firewall-cmd --list-all
  344  firewall-cmd --zone=public --permanent --add-port=3306/tcp
  345  firewall-cmd --reload
  346  firewall-cmd --list-all
  347  mysql -u root -p
  348  history
  349  cat history
  350  cd ..
  351    1  cd /etc/yum.repos.d/
  352      2  ls -ls
  353      3  yum
  354      4  export http_proxy=http://144.144.2.57:3128
  355      5  export https_proxy=http://144.144.2.57:3128
  356      6  cd
  357      7  rmp -qa |grep yum
  358      8  rpm -qa |grep yum
  359      9  export http_proxy=http://144.144.2.57:3128
  360     10  export https_proxy=http://144.144.2.57:3128
  361     11  rpm -qa |grep yum
  362     12  ls
  363     13  cd var
  364     14  cd home
  365     15  cd ..
  366     16  ls
  367     17  cd var
  368     18  ls
  369     19  cd cache
  370     20  ls
  371     21  cd
  372     22  yum check-update
  373     23  yum list
  374     24  yum list php
  375     25  yum info php
  376     26  uname -or
  377     27  cat /etc/lsb-release
  378     28  yum list php
  379     29  cd ..
  380     30  ls
  381     31  cd cat
  382     32  cd etc
  383     33  ls
  384     34  cd centos-release
  385     35  usname -a
  386     36  cd ..
  387     37  usname -a
  388     38  cat/etc/centos-release
  389     39  uname -a
  390     40  yum - install phw70w
  391     41  yum -y install php70w
  392     42  yum search epel-release
  393     43  yum instal epel-release
  394     44  lsb_release -a
  395     45  uname -a
  396     46  ls
  397     47  cd dev
  398     48  ls
  399     49  cd cdrom
  400     50  ls -l /dev/cdrom
  401     51  cd ..
  402     52  ls
  403     53  cd mnt
  404     54  ls
  405     55  sudo mount -t iso9660 -o ro /dev/cdrom /mnt cdrom
  406     56  ls
  407     57  cd..
  408     58  cd
  409     59  ls
  410     60  cd ..
  411     61  ls
  412     62  cd mnt
  413     63  ls
  414     64  cd ..
  415     65  cd
  416     66  ls
  417     67  cd ..
  418     68  ls
  419     69  sudo mount -t iso9660 -o ro /dev/cdrom /mnt cdrom
  420     70  ls
  421     71  cd mnt
  422     72  ls
  423     73  mount /dev/sr0 /mnt/cdrom
  424     74  mkdir /mnt/cdrom
  425     75  cd mnt
  426     76  cd mnk
  427     77  ls
  428     78  mount /dev/sr0 /mnt/cdrom
  429     79  cd dev
  430     80  cd..
  431     81  cd ..
  432     82  cd dev
  433     83  ls
  434     84  mount /dev/cdrom  /mnt/cdrom
  435     85  df cdrom
  436     86  ls
  437     87  cd ..
  438     88  ls
  439     89  mount /dev/cdrom /mnt
  440     90   cd/mnt
  441     91  cd /mnt
  442     92  ls
  443     93  rmdir cdrom
  444     94  ls
  445     95  yum list
  446     96  cd ..
  447     97  cat /etc/os-release
  448     98  rpm -Uvh https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm
  449     99  rpm -Uvh https://mirror.webtatic.com/yum/el7/webtatic-release.rmp
  450    100  rpm -Uvh https://mirror.webtatic.com/yum/el7/webtatic-release.rpm
  451    101  yum install php70w
  452    102  yum info php
  453    103  yum list php
  454    104  ls
  455    105  cd var/www
  456    106  ls
  457    107  cd html
  458    108  ls
  459    109  cd..
  460    110  cd ..
  461    111  yum -y install php70w
  462    112  systemct1 restart httpd.service
  463    113  systemctl restart httpd.service
  464    114  ls
  465    115  cd html
  466    116  ls
  467    117  cd ..
  468    118  cd
  469    119  ls
  470    120  yum install httpd
  471    121  yum install httpd mysql mysql-server php php-mysql
  472    122  cd..
  473    123  ls
  474    124  cd
  475    125  cd ..
  476    126  cd etc/httpd/conf
  477    127  ls
  478    128  cd ..
  479    129  ls
  480    130  cd conf.d
  481    131  ls
  482    132  cd ..
  483    133  cd /var/www
  484    134  ls
  485    135  cd html
  486    136  ls
  487    137  cd /var /www/error
  488    138  ls
  489    139  vim /etc/hosts
  490    140  yum install vim
  491    141  vim /etc/hosts
  492    142  vim /etc/httpd/conf/httpd.conf
  493    143  cd /etc/httpd/conf.d
  494    144  ls
  495    145  ll *.conf
  496    146  /etc/init.d/httpd start
  497    147  yum install httpd
  498    148  yum install mysql
  499    149  cd ..
  500    150  cd
  501    151  yum install mysql mysql-server
  502    152  service mysqld start
  503    153  systemct1 start mysql
  504    154  yum install mysql-community-server
  505    155  rpm -Uvh http://dev.mysql.com/get/mysql-community-release-el7-5.noarch.rpm
  506    156  yum install mysql-community-server
  507    157  ls /usr/bin
  508    158  /usr/bin/systemctl enable mysqld
  509    159  /usr/bin/systemctl start mysqld
  510    160  /usr/bin/mysql_secure_installation
  511    161  yum -y install httpd
  512    162  systemctl start httpd.service
  513    163  systemctl enable httpd.service
  514    164  firewall-cmd --permanent --zone=public --add-service=http
  515    165  firewall-cmd --permanent --zone=public --add-service=https
  516    166  firewall -cmd --reload
  517    167  firewall-cmd --reload
  518    168  vim /ect/httpd/conf/httpd.conf
  519    169  yum -y install php70w
  520    170  systemctl restart httpd.service
  521    171  cd /etc
  522    172  ls
  523    173  vim php.ini
  524    174  cd /var/www/html
  525    175  ls
  526    176  pwd
  527    177  vim info.php
  528    178  php /var/www/html/info.php
  529    179  cd
  530    180  yum search php
  531    181  yum -y install php70w-mysql
  532    182  yum -y install php70w-pdo php70w-gd php70w-ldap php70w-odbc php70w-pear.noarch php70w-xml php70w-xmlrpc php70w-mbstring php70w-snmp php70w-soap php70w-mcrypt curl curl-devel
  533    183  mysql_secure_installation
  534    184  yum install php
  535    185  systemctl restrat httpd.service
  536    186  systemctl restart httpd.service
  537    187
  538    188  sudo ip addr show
  539    189  php /var/www/html
  540    190  vim /var/www/html/info.php
  541    191  php /var
  542    192  php /var/www/html/test.php
  543    193  vim /var/
  544    194  php /var/www/html
  545    195  if
  546    196  nslook
  547    197  yum ins
  548    198  nsloo
  549    199  cd
  550    200  ls
  551    2
  552    202  ls
  553    203  rename t
  554    204  mv
  555    205  ls
  556    206  cat index.php
  557
  558    208  ls
  559    209
  560    210  ls
  561    211  pw
  562    212  cd /etc/http
  563    213  ls
  564    214
  565    215  irm httpd.com
  566    216
  567    217  rm httpd.con
  568    218  vim h
  569    219  pw
  570    220  vim ht
  571    221  php /v
  572    222  cd
  573    223  ls
  574    224  ifconfi
  575    225  ls
  576    226
  577    227  cd /e
  578    228  ls
  579    229
  580    230  cd yum
  581    231  ls
  582    232
  583    233  ls
  584    234
  585    235  cd
  586    236  cd ..
  587    23
  588    238  cd usr
  589    239  cd loca
  590    240  ls
  591    241  cd mysql
  592    24
  593    243  ls
  594    244  cd ..
  595    245
  596    246  find mysql
  597    2
  598    248  ls
  599    249
  600    250  my
  601    251  mysql
  602    252  my
  603    253  mysql -u
  604    254  /usr/bin/mysql_s
  605    255  mysql
  606    256  cd
  607    257  ls
  608    2
  609    259  cd
  610    260  ls
  611    261  vi pdo.ini
  612    262  yum php70w-xml
  613    263
  614    264  yu
  615    265  ls -
  616    266  ls
  617    267  yu
  618    268  ls -l
  619    269  my
  620    270  df -h
  621    271  fdi
  622    272  cd /d
  623    273  ls
  624    274  cd
  625    275  ls
  626
  627    277  cd
  628    278  mount
  629    279  lsblk
  630    280  mkdir mycdrom
  631    281  ls
  632    282  cd
  633    283  ls
  634    2
  635    285  ls
  636    286  cd html
  637    287  cd
  638    288
  639    289  cd /var/www/html
  640    290  ls
  641    2
  642    292  system
  643    293  sy
  644    294  systemctl disable httpd
  645
  646    296  system
  647    297  syst
  648    298  syste
  649    299  system
  650    300  sy
  651    301  ps aux
  652    302  ps aux | more
  653    303  ps aux |    304  ps
  654    305  ls
  655
  656    307  ph
  657    308  cd /var/www/html/
  658    3
  659    310  php gg.
  660    311  ls
  661    31
  662    313  he
  663    314  cd /var/www
  664    315  ls
  665    316  cd html
  666    317  ls
  667    3
  668    319  nohup php gg.php >/
  669    320  systemctl status firewalld
  670    321  systemctl status iptables
  671    322  systemctl st
  672    323  systemctl status firewalld
  673    324  firewalld-cmd --list-all
  674    325
  675    326  firewalld --list
  676    327  firewalld --list-all
  677    328  firewall --li
  678    329  firewall-cmd --lis
  679    330  cd /usr/lib/
  680    331  ls
  681    332  vi
  682    333  fi
  683    334  firewall-c
  684    335  fi
  685    336  firewal
  686    337  fi
  687    338  fire
  688    339  firew
  689    340  firewall-cmd --reload
  690    341  firewall-cmd --list-all
  691    342
  692    343  firewall-cmd --reload
  693    344  fi
  694    345  my
  695    346  history
  696  cd
  697  cd /var/www/html
  698  ls
  699  vim sql.php
  700  exit
  701  ps aux | grep pph
  702  ps aux | grep php
  703  ps aux | grep gg.php
  704  ps aux | grep gg
  705  kill -9 19583
  706  ps aux | grep php
  707  crontab -e
  708  export
  709  ls -ls
  710  crontab -e
  711  ~/.bash_pr
  712  mysql -u root -p
  713  cat history
  714  history
  715  exit
  716  cd /var/www
  717  ls
  718  cd html
  719  ls
  720  vim test.php
  721  ls
  722  vim test.php
  723  ls
  724  cat test.php
  725  vim test.php
  726  cat test.php
  727  vim test.php
  728  logout
  729  cd /etc/selinux/config
  730  cd /etc/selinux/
  731  ls
  732  cd config
  733  vi config
  734  reboot
  735  mysql
  736  mysql -uroot cj;6u6xu/6
  737  mysql -u root -p
  738  mysql -u root
  739  mysql -u root -p
  740  cd /usr/local/src/
  741  ls
  742  cd
  743  rpm -qa | grep jquery
  744  yum search jquery
  745  EXIT
  746  exit
  747  php composer-setup.php --install-dir=bin
  748  --install-dir
  749  php -r "copy('https://getcomposer.org/installer', 'composer-setup.php');"
  750  php -r "readfile('https://getcomposer.org/installer');"
  751  curl https://getcomposer.org/installer > composer-setup.php
  752  cd..
  753  cd
  754  php -r "copy('http://getcomposer.org/installer', 'composer-setup.php');"
  755  curl -sS https://getcomposer.org/installer | php
  756  curl --proxy-root user:cj;6u6xu/6 https://getcomposer.org/installer > composer-setup.php
  757  export http_proxy=http://144.144.2.57:3128
  758  export https_proxy=http://144.144.2.57:312
  759  php -r "copy('https://getcomposer.org/installer', 'composer-setup.php');"
  760  php -r "copy('http://getcomposer.org/installer', 'composer-setup.php');"
  761  export https_proxy=http://144.144.2.57:3128
  762  php -r "copy('http://getcomposer.org/installer', 'composer-setup.php');"
  763  export https_proxy=http://144.144.2.97
  764  export http_proxy=http://144.144.2.97
  765  php -r "copy('https://getcomposer.org/installer', 'composer-setup.php');"
  766  export http_proxy=http://144.144.2.57:3128
  767  export https_proxy=http://144.144.2.57:3128
  768  export https_proxy=http://144.144.2.57:3128
  769  export http_proxy=http://144.144.2.57:3128
  770  php -r "copy('http://getcomposer.org/installer', 'composer-setup.php');"
  771  curl -sS https://getcomposer.org/installer | php
  772  cd /composer.phar
  773  cd /root
  774  pwd
  775  ls
  776  php -r "if (hash_file('SHA384', 'composer-setup.php') === '669656bab3166a7aff8a7506b8cb2d1c292f042046c5a994c43155c0be6190fa0355160742ab2e1c88d40d5be660b410') { echo 'Installer verified'; } else { echo 'Installer corrupt'; unlink('composer-setup.php'); } echo PHP_EOL;"
  777  fied'; } else { echo 'Installer corrupt'; unlink('composer-setup.php'); } echo PHP_EOL;"
  778  exit
  779  dsf
  780  :
  781  ;
  782  q
  783  q:
  784  q:!
  785  ls
  786  curl -sS https://getcomposer.org/installer | php
  787  export http_proxy=http://144.144.2.57:3128
  788  export https_proxy=http://144.144.2.57:3128
  789  curl -sS https://getcomposer.org/installer | php
  790  ls
  791  php -r "if (hash_file('SHA384', 'composer-setup.php') === 'e115a8dc7871f15d853148a7fbac7da27d6c0030b848d9b3dc09e2a0388afed865e6a3d6b3c0fad45c48e2b5fc1196ae') { echo 'Installer verified'; } else { echo 'Installer corrupt'; unlink('composer-setup.php'); } echo PHP_EOL;"
  792  rm composer.phar
  793  ls
  794  curl -sS https://getcomposer.org/installer | php
  795  ls
  796  php composer-setup.php --install-dir=bin --filename=composer
  797  php -r "unlink('composer-setup.php');"
  798  php composer-setup.php
  799  php -r "copy('https://getcomposer.org/installer', 'composer-setup.php');"
  800  php -r "copy('http://getcomposer.org/installer', 'composer-setup.php');"
  801  curl -sS https://getcomposer.org/installer | php -- --install-dir=bin --filename=composer
  802  ls
  803  cd home
  804  ls
  805  cd ..
  806  ls
  807  curl -sS https://getcomposer.org/installer | php -- --install-dir=bin --filename=composer
  808  cd bin
  809  ls
  810  composer -V
  811  php bin/composer
  812  ls
  813  php bin/composer
  814  php composer.phar install
  815  composer -v
  816  cd composer
  817  ld
  818  ls
  819  cat composer
  820  PuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTY
  821  more composer
  822  cd /
  823  cd bin
  824  php composer.phar
  825  ls
  826  php composer
  827  cd
  828  cd /
  829  ls
  830  cd usr
  831  ls
  832  cd local
  833  ls
  834  cd
  835  ls
  836  mv comoser.phar /usr/local/bin/composer
  837  mv composer.phar /usr/local/bin/composer
  838  cd /usr/local/bin
  839  ls
  840  cd composer
  841  ls
  842  cd composer
  843  ls
  844  cd
  845  ls
  846  composer -v
  847  php version
  848  phpinfo() fds
  849  php -version
  850  composer require monolog/monolo
  851  history
