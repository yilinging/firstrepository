<?php

$hosthame="127.0.0.1";
$database="test";
$username="root";
$password="cj;6u6xu/6";

$mysqli = new mysqli($hostname, $username, $password, $database);

//$myquery=new myquery();
//$mysqlselect = '2';
$mysqlselect = $_GET['sqlselect'];
$i=0;


if ($result = $mysqli->query("SELECT * from gg")) {

    /* fetch object array */
    while ($row = $result->fetch_row()) {
        //echo  $row[0],$row[1];
        $test[$i][0]=$row[0];
        $test[$i][1]=$row[1];
        $i++;
        //echo "<br>"."i= ".$i."<br>";
        //echo "<br>";
    }
    /* free result set */
    $result->close();
}
else
    echo 'Fail';


for ($j=0;$j<$i;$j++){
    //一維陣列
    $A[$j]= $test[$j][0];
    $B[$j]= $test[$j][1];
    //二微陣列
    $AB[$j][0]= $test[$j][0];
    $AB[$j][1]= $test[$j][1];
    if ($mysqlselect==$AB[$j][0])
    {
        $selectresultid=$AB[$j];
    }
    //echo json_encode(["id2"=>$AB[$j]]);//二維陣列直接印ok

    //echo $A[j];
    //echo $B[j];
   // echo "<br>";
    //echo json_encode(["id2"=>"id is $A[$j]","hi"=>"hi is $B[$j]"]);//false
}
echo json_encode(["sqlid"=>$AB,"sqlresult"=>$selectresultid]);
//echo json_encode(["id2"=>$A[0],"hi"=>"${B[0]}","sqlid"=>"Your SQL select id result is $selectresultid","sqlhi"=>"Your SQL select hi result is $selectresulthi"]);
//echo json_encode(["id2"=>$A,"hi"=>"${B[0]}","sqlid"=>"Your SQL select id result is $selectresultid","sqlhi"=>"Your SQL select hi result is $selectresulthi"]);
//echo json_encode(["id2"=>$AB[1]]);//二維陣列ok


//insert語法 ok
/*if ($result = $mysqli->query("INSERT INTO gg VALUES (8,'jjjjjjjjj')")) {

    $result->close();
}
else
    echo 'Fail';*/




//echo "success";
//mysqli_close($link);

?>
