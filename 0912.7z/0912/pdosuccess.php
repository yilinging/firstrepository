<?php
//首先，先來定義資料庫相關存取資料
$db_host="127.0.0.1";
$db_user="root";
$db_pass="cj;6u6xu/6";
$db_select="test";

//使用PDO存取資料庫時，需要將資料庫依下列格式撰寫，讓程式讀取資料庫
$dbconnect = "mysql:host=".$db_host.";dbname=".$db_select;

//建立使用PDO方式連線的物件，並放入指定的相關資料
$dbgo = new PDO($dbconnect, $db_user, $db_pass);

$j=0;
//建立查詢資料表的SQL語法
$sql = "SELECT * FROM gg";

if($result = $dbgo->query($sql)){
  while($row=$result->fetchAll(PDO::FETCH_ASSOC)){
    //print_r($row);
    foreach ($row as $arrValues){
      $i=0;
      foreach ($arrValues as $key => $val){
        //echo $val;
        //echo "<br>";
        if($i==0)
          $AB[$j][0]= $val;
        else
         $AB[$j][1]= $val;
       $i++;
     }
     $j++;
   }
 }
}

for ($x=0;$x<$j;$x++){
    //一維陣列
  for ($y=0;$y<2;$y++){
    echo $AB[$x][$y]."  ";
    
  }
}


//$link=mysqli_connect($hostname,$username,$password);

/* ok
try {
    $dbh = new PDO('mysql:host=127.0.0.1;dbname=test', $username, $password);
   foreach($dbh->query('SELECT * from gg') as $row) {
        print_r($row);
        echo '<br>';
    }
    $dbh = null;
} catch (PDOException $e) {
    echo 'Connection failed: ' . $e->getMessage();
}
*/

/*
//執行並查詢，查詢後只回傳一個查詢結果的物件，必須使用fetc、fetcAll...等方式取得資料
$result = $dbgo->query($sql);
echo "result";
echo $result;
echo "<br>";

//取出第一筆資料，以此例來說就是最先存入資料庫的那一筆資料
$row=$result->fetch();
echo "row1";
echo $row;
echo "<br>";

//抓出全部但是除了使用欄位名稱存成陣列之外，還會依照順序再另外存成一組陣列，結果如下
$row=$result->fetchAll();
$row=$result->fetch();
echo "row2";
echo $row;
echo "<br>";

//加入FETCH_ASSOC，代表要將取出的資料已關聯性的方式存成陣列，同時也適用於各式抓取資料的方法(如上面提到的fetch)，結果如下
$row=$result->fetchAll(PDO::FETCH_ASSOC);
$row=$result->fetch();
echo "row3";
echo $row;
echo "<br>";
*/


/*
//Only print first row
try {
  $dbh = new PDO('mysql:host=127.0.0.1;dbname=test', $username, $password);
  foreach($dbh->query('SELECT * from gg') as $row) {
    echo 'row';
    print_r($row);
    echo '<br>';
    echo '<br>';
    $result=$row->fetch();
    echo 'result';
    print_r($result);
    echo '<br>';
  }
  $dbh = null;
} catch (PDOException $e) {
  echo 'Connection failed: ' . $e->getMessage();
}*/






 /*$dbh = new PDO('mysql:host=127.0.0.1;dbname=test', $username, $password);


if ($result = $dbh->query('SELECT * from gg'))
    {
        while($row = $result->fetch_assoc())
        {
           print_r($row);   
       }    
       echo 'success';
   }else
   echo 'Fail'*/




/*
    $mysqli = new mysqli($hostname, $username, $password, "test");
    if ($result = $mysqli->query("SELECT * from gg"))
    {
        while($row = $result->fetch_assoc())
        {
           print_r($row);	
       }    
   }else
   echo 'Fail';*/




//$link=mysqli_connect($hostname,$username,$password,$database) or die ("無法開啟Mysql資料庫連結");

//if(mysqli_select_db($database))
//	echo 'get db';


//$SQL = "SELECT * FROM gg"; 
//$result = mysqli_query($SQL, $link) or die('Error in query');


//$row = mysqli_fetch_array($SQL);
//echo $row;

//$sql ="SELECT * FROM gg" or die('MySQL query error');

//echo $sql;

    /*$sql = 'SELECT * FROM gg ';   
     mysqli_query($sql);  
     $row = mysqli_fetch_array($result);
     echo $row[0]; */      

       /* $result = mysqli_query($sql) or die('MySQL query error');
    while($row = mysqli_fetch_array($result)){
        echo $row['name'];
      }*/
//$sql="INSERT INTO gg (id, hi) VALUES('7','abcdefg');";
/*mysqli_query("INSERT INTO gg (id, hi) 
  VALUES ('6', 'bbb')");*/
//$sql = "INSERT INTO 'gg' (id, hi) VALUES ("4","aaaa")";
/*mysqli_select_db($database);

$alldata="SELECT * FROM gg";

$printalldata = mysqli_query($alldata);

while($row=musql_fetch_array($result)){
	echo $row['查詢欄位1']."";
	echo $row['查詢欄位2']."<br>";
}*/

//echo $alldata;

//echo "success";
//mysqli_close($link);

?>