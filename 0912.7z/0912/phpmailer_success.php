<?php
//Import PHPMailer classes into the global namespace
//use PHPMailer\PHPMailer\PHPMailer;
//use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

$mail = new PHPMailer\PHPMailer\PHPMailer(true);
//$mail = new PHPMailer(true);
//$mail = new PHPMailer();
//$mail = new PHPMailer;

try {
    //Server settings
    $mail->SMTPDebug = 2;                                 // Enable verbose debug output
    $mail->isSMTP();                                      // Set mailer to use SMTP
    $mail->Host = 'lpmail.largan.com.tw';  // Specify main and backup SMTP servers
    // 設定安全驗證開啟
    $mail->SMTPAuth = true;    
                               // Enable SMTP authentication
    $mail->Username = 'yilinghuang@largan.com.tw';                 // SMTP username
    $mail->Password = '';                           // SMTP password
    //$mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
    // 設定SMTP服務的POST
    $mail->Port = 587;                                    // TCP port to connect to
    $mail->SMTPAutoTLS = false;
    //Recipients
    $mail->setFrom('yilinghuang@largan.com.tw', 'Ling');
   // $mail->addAddress('joe@example.net', 'Joe User');     // Add a recipient
    // 設定收件者EMail(有加名稱)
    $mail->addAddress('yilinghuang@largan.com.tw',"YiLing");               // Name is optional
    // 設定回信EMail及名稱
    $mail->addReplyTo('yilinghuang@largan.com.tw', 'yiling');
    // 設定收件者EMail(無名稱)

//$mail->AddAddress("erichuang@tongtai.com.tw");
    // 設定副本
    //$mail->addCC('cc@example.com');
    // 設定密件副本
    //$mail->addBCC('bcc@example.com');

    //Attachments
    //$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
    $mail->addAttachment('/var/www/html/myproject/phpmailer_success.php', 'new.php');    // Optional name

    //Content
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = 'Test';
    $mail->Body    = 'This is the HTML message body <b>in bold!</b>';
    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
   
    $mail->send();

    echo 'Message has been sent';
} catch (PHPMailer\PHPMailer\Exception $e) {
    //} catch (Exception $e) {
    echo 'Message could not be sent.';
    echo 'Mailer Error: ' . $mail->ErrorInfo;
}