<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>取得mysql資料庫中的資料</title>
</head>
<body>
<?php




$hosthame="127.0.0.1";
$database="test";
$username="root";
$password="cj;6u6xu/6";

//$link=mysqli_connect($hostname,$username,$password);









$mysqli = new mysqli($hostname, $username, $password, "test");
if ($result = $mysqli->query("SELECT * from gg"))
{
    while($row = $result->fetch_assoc())
    {
    	print_r($row);	
    }    
}else
	echo 'Fail';




//$link=mysqli_connect($hostname,$username,$password,$database) or die ("無法開啟Mysql資料庫連結");

//if(mysqli_select_db($database))
//	echo 'get db';


//$SQL = "SELECT * FROM gg"; 
//$result = mysqli_query($SQL, $link) or die('Error in query');


//$row = mysqli_fetch_array($SQL);
//echo $row;

//$sql ="SELECT * FROM gg" or die('MySQL query error');

//echo $sql;

    /*$sql = 'SELECT * FROM gg ';   
     mysqli_query($sql);  
     $row = mysqli_fetch_array($result);
     echo $row[0]; */      

       /* $result = mysqli_query($sql) or die('MySQL query error');
    while($row = mysqli_fetch_array($result)){
        echo $row['name'];
    }*/
//$sql="INSERT INTO gg (id, hi) VALUES('7','abcdefg');";
/*mysqli_query("INSERT INTO gg (id, hi) 
VALUES ('6', 'bbb')");*/
//$sql = "INSERT INTO 'gg' (id, hi) VALUES ("4","aaaa")";
/*mysqli_select_db($database);

$alldata="SELECT * FROM gg";

$printalldata = mysqli_query($alldata);

while($row=musql_fetch_array($result)){
	echo $row['查詢欄位1']."";
	echo $row['查詢欄位2']."<br>";
}*/

//echo $alldata;

//echo "success";
//mysqli_close($link);

?>
</body>
</html>


