<?php
error_reporting(-1);
ini_set("display_errors", 1);
require_once "vendor/autoload.php";
require_once "vendor/phpexcel/phpexcel/Classes/PHPExcel.php";



$objPHPExcel = new PHPExcel();

for ($j = 0; $j <= 2; $j++) {
 
// [2]create
      if ($j > 0) 
      $objPHPExcel->createSheet();
      $objPHPExcel->setActiveSheetIndex($j);
 
// [3]format
      $objPHPExcel->getActiveSheet()->setTitle();
      $objPHPExcel->getActiveSheet()->getDefaultRowDimension()->setRowHeight(25);
 
      for($col = 'A'; $col !== 'D'; $col++) {
          // 指定寬度
          $objPHPExcel->getActiveSheet()->getColumnDimension($col)->setWidth(15);
          // 水平置中
          $objPHPExcel->getActiveSheet()->getStyle($col)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
          // 垂直置中
          $objPHPExcel->getActiveSheet()->getStyle($col)->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
      }
 
// [4]data      
      $arr_data       = array(); 
      $arr_data[0][0] = '欄位一';
      $arr_data[0][1] = '欄位二';
      $arr_data[0][2] = '欄位三';
      $arr_data[1][0] = '資料一';
      $arr_data[1][1] = '資料二';
      $arr_data[1][2] = '資料三';
      $arr_data[2][0] = '資料一';
      $arr_data[2][1] = '資料二';
      $arr_data[2][2] = '資料三';
 
      $objPHPExcel->getActiveSheet()->fromArray($arr_data, null, 'A1');
     }
 
// [5]open from the first sheet
     $objPHPExcel->setActiveSheetIndex(0);
 
// [6]output
     header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
     header('Content-Disposition: attachment;filename="download.xlsx"');
     header('Cache-Control: max-age=0');
     $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
     $objWriter->save('php://output');
     exit;
?>