確認CD是否有裝目前是有裝的狀況
lsblk

掛載CD
mount -t iso9660 /dev/sr0 /mycdrom
卸載
umount /mycdrom


掛載網芳空間需要安裝
yum install samba-client samba-common cifs-utils

mount -t cifs -o user= yilinghuang,domain=largan.com.tw[,uid=48,gid=48 裝作本機的哪個使用者擁有]  '//網芳資料夾’ /本機資料夾
Umount  /本機資料夾


mount -t cifs -o user=yilinghuang,domain=largan.com.tw //lp-fs1.largan.com.tw/IT/temp/elan/CentOS /mycdrom